from flask import Flask, request, jsonify, render_template, send_from_directory
from SPARQLWrapper import SPARQLWrapper, JSON
import math

app = Flask(__name__)

SPARQL_ENDPOINT = "http://localhost:7200/repositories/Test2"

def execute_sparql_query(query):
    sparql = SPARQLWrapper(SPARQL_ENDPOINT)
    sparql.setQuery(query)  
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    return results

# Root route
@app.route('/')
def home():
    return render_template('index.html')

# Endpoint to fetch main table data
@app.route('/data', methods=['POST'])
def get_table_data():
    filters = request.json
    program_filter = filters.get('program', '')
    university_filter = filters.get('university', '')
    scholarship_filter = filters.get('scholarship', '')

    query = f"""
    PREFIX BDM: <http://www.example.edu/>
    SELECT ?program ?programTitle ?universityName (GROUP_CONCAT(?scholarshipTitle; separator=", ") AS ?scholarshipTitles) WHERE {{
        ?program rdf:type BDM:program .
        ?program BDM:title ?programTitle .
        ?program BDM:from_uni ?university .
        ?university BDM:name ?universityName .
        OPTIONAL {{
            ?scholarship BDM:eligible_for ?program .
            ?scholarship BDM:award_name ?scholarshipTitle .
        }}
        {f'FILTER (CONTAINS(LCASE(STR(?programTitle)), LCASE("{program_filter}")))' if program_filter else ''}
        {f'FILTER (CONTAINS(LCASE(STR(?universityName)), LCASE("{university_filter}")))' if university_filter else ''}
        {f'FILTER (CONTAINS(LCASE(STR(?scholarshipTitle)), LCASE("{scholarship_filter}")))' if scholarship_filter else ''}
    }}
    GROUP BY ?program ?programTitle ?universityName
    ORDER BY ?programTitle
    """
    results = execute_sparql_query(query)
    return jsonify(results)

# Endpoint to fetch program filter options
@app.route('/filter/program', methods=['GET'])
def get_programs():
    query = """
    PREFIX BDM: <http://www.example.edu/>
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    SELECT DISTINCT ?programTitle WHERE {
        ?program rdf:type BDM:program .
        ?program BDM:title ?programTitle .
    }
    ORDER BY ?programTitle
    """
    results = execute_sparql_query(query)
    return jsonify(results)

# Endpoint to fetch university filter options
@app.route('/filter/university', methods=['GET'])
def get_universities():
    query = """
    PREFIX BDM: <http://www.example.edu/>
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    SELECT DISTINCT ?universityName WHERE {
        ?university rdf:type BDM:university .
        ?university BDM:name ?universityName .
    }
    ORDER BY ?universityName
    """
    results = execute_sparql_query(query)
    return jsonify(results)

@app.route('/program/<program_name>')
def program_page(program_name):
    program_details = fetch_program_details(program_name)

    query = f"""
    PREFIX BDM: <http://www.example.edu/>
    SELECT ?scholarshipTitle ?amount WHERE {{
        ?program BDM:title "{program_name}" .
        ?scholarship BDM:eligible_for ?program .
        ?scholarship BDM:award_name ?scholarshipTitle .
        ?scholarship BDM:amount ?amount .
    }}
    """
    results = execute_sparql_query(query)
    
    scholarships = []
    for result in results["results"]["bindings"]:
        scholarship = {
            'award_name': result["scholarshipTitle"]["value"],
        }
        scholarships.append(scholarship)

    recommendations_query = f"""
    PREFIX BDM: <http://www.example.edu/>
    SELECT ?title
    WHERE {{
        ?program BDM:title "{program_name}" .
        ?program BDM:recommends ?recommended_program .
        ?recommended_program BDM:title ?title
    }}
    """
    recommendations_results = execute_sparql_query(recommendations_query)
    recommended_programs = [
        {'name': result["title"]["value"].split("/")[-1]} 
        for result in recommendations_results["results"]["bindings"]
    ]
    print(recommendations_results)
    print(recommended_programs)

    opinion_query = f"""
    PREFIX BDM: <http://www.example.edu/>
    SELECT ?comment ?date ?feedback ?topic ?user ?name ?email ?register_date
    WHERE {{
        ?review BDM:opinion_of ?program .
        ?program BDM:title "{program_name}" .
        OPTIONAL {{ ?review BDM:comment ?comment . }}
        OPTIONAL {{ ?review BDM:date ?date . }}
        OPTIONAL {{ ?review BDM:feedback ?feedback . }}
        OPTIONAL {{ ?review BDM:topic ?topic . }}
        OPTIONAL {{ 
            ?user BDM:writes ?review .
            ?user BDM:name ?name ;
                BDM:email ?email ;
                BDM:register_date ?register_date .
        }}
    }}
    """
    opinion_results = execute_sparql_query(opinion_query)
    opinions = []
    for result in opinion_results["results"]["bindings"]:
        opinion = {
            'comment': result.get("comment", {}).get("value", ""),
            'date': result.get("date", {}).get("value", ""),
            'feedback': result.get("feedback", {}).get("value", ""),
            'topic': result.get("topic", {}).get("value", ""),
            'user': {
                'name': result.get("name", {}).get("value", ""),
                'email': result.get("email", {}).get("value", ""),
                'register_date': result.get("register_date", {}).get("value", "")
            }
        }
        opinions.append(opinion)

    return render_template('program.html', program=program_details, scholarships=scholarships, opinions=opinions, recommended_programs=recommended_programs)

def fetch_program_details(program_name):
    query = f"""
    PREFIX BDM: <http://www.example.edu/>
    SELECT ?description ?bachelor_needed ?duration ?eng_lvl ?spa_lvl ?score ?st_date WHERE {{
        ?program rdf:type BDM:program .
        ?program BDM:title "{program_name}" .
        OPTIONAL {{ ?program BDM:description ?description . }}
        OPTIONAL {{ ?program BDM:bachelor_needed ?bachelor_needed . }}
        OPTIONAL {{ ?program BDM:duration ?duration . }}
        OPTIONAL {{ ?program BDM:eng_lvl ?eng_lvl . }}
        OPTIONAL {{ ?program BDM:spa_lvl ?spa_lvl . }}
        OPTIONAL {{ ?program BDM:score ?score . }}
        OPTIONAL {{ ?program BDM:st_date ?st_date . }}
    }}
    """
    results = execute_sparql_query(query)
    program_details = {
        'name': program_name,
        'description': results["results"]["bindings"][0]["description"]["value"] if "description" in results["results"]["bindings"][0] else "",
        'bachelor_needed': results["results"]["bindings"][0]["bachelor_needed"]["value"] if "bachelor_needed" in results["results"]["bindings"][0] else "",
        'duration': results["results"]["bindings"][0]["duration"]["value"] if "duration" in results["results"]["bindings"][0] else "",
        'eng_lvl': results["results"]["bindings"][0]["eng_lvl"]["value"] if "eng_lvl" in results["results"]["bindings"][0] else "",
        'spa_lvl': results["results"]["bindings"][0]["spa_lvl"]["value"] if "spa_lvl" in results["results"]["bindings"][0] else "",
        'score': results["results"]["bindings"][0]["score"]["value"] if "score" in results["results"]["bindings"][0] else "",
        'st_date': results["results"]["bindings"][0]["st_date"]["value"] if "st_date" in results["results"]["bindings"][0] else ""
    }
    return program_details

@app.route('/images/<path:filename>')
def serve_image(filename):
    return send_from_directory('images', filename)

@app.route('/scholarship/<scholarship_name>')
def scholarship_page(scholarship_name):
    query = f"""
    PREFIX BDM: <http://www.example.edu/>
    SELECT ?award_name ?nationality ?academic_perf ?amount ?num_awards ?score ?spa_lvl ?eng_lvl ?bachelor_needed ?max_age ?min_age ?deadline
    WHERE {{
        ?scholarship BDM:award_name "{scholarship_name}" .
        OPTIONAL {{ ?scholarship BDM:award_name ?award_name . }}
        OPTIONAL {{ ?scholarship BDM:nationality ?nationality . }}
        OPTIONAL {{ ?scholarship BDM:academic_perf ?academic_perf . }}
        OPTIONAL {{ ?scholarship BDM:amount ?amount . }}
        OPTIONAL {{ ?scholarship BDM:num_awards ?num_awards . }}
        OPTIONAL {{ ?scholarship BDM:score ?score . }}
        OPTIONAL {{ ?scholarship BDM:spa_lvl ?spa_lvl . }}
        OPTIONAL {{ ?scholarship BDM:eng_lvl ?eng_lvl . }}
        OPTIONAL {{ ?scholarship BDM:bachelor_needed ?bachelor_needed . }}
        OPTIONAL {{ ?scholarship BDM:max_age ?max_age . }}
        OPTIONAL {{ ?scholarship BDM:min_age ?min_age . }}
        OPTIONAL {{ ?scholarship BDM:deadline ?deadline . }}
    }}
    """

    results = execute_sparql_query(query)
    scholarship_details = {}
    for key in ["award_name", "nationality", "academic_perf", "amount", "num_awards", "score", "spa_lvl", "eng_lvl", "bachelor_needed", "max_age", "min_age", "deadline"]:
        value = results["results"]["bindings"][0].get(key, {}).get("value", None)
        if value is not None and value != "nan":
            scholarship_details[key] = value

    return render_template('scholarship.html', scholarship=scholarship_details)

if __name__ == '__main__':
    app.run(debug=True)